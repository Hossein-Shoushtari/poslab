In this directory you will find all generated and simulated data. Feel free to use it!

1) In the 'draw' directory you will find the drawings that you may have made on our website.
2) 'gt' stands for 'Ground Truth'. There you will find all generated ground truth trajectories
   based on the specific sensor data and waypoints you provided.
3) 'sm' stands for 'simulated measurements'. All simulated trajectories can be found here.